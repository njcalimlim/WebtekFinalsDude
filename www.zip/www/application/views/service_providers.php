<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Service Providers</title>

    <!-- Bootstrap Core CSS -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="assets/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="assets/vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="assets/vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="assets/dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- toggle switch -->
    <link href="assets/css/toggle.css" rel="stylesheet" type="text/css">
    <link href="assets/css/confirm.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Welcome Admin</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu alert-dropdown">
                        <li>
                            <a href="#">Christine De Alban would like to tutor Bass <span class="label label-info">View Info</span></a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a class="text-center" href="notifications.html">
                                <strong>View All Request</strong>
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </li>
                    </ul>
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="<?php echo base_url(); ?>login"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                         <li>
                            <i class="fa fa-dashboard fa-fw"></i><strong>Home-Admin</strong>
                        </li>                   
                        <li>
                            <a href="<?php echo base_url(); ?>request"><i class="fa fa-dashboard fa-fw"></i>Dashboard</a>
                        </li>
                        <li>
                            <i <!-- class="fa fa-table fa-fw" --></i><strong>SP Registration Request</strong>
                        </li>
                        <li>
                            <a href="<?php echo base_url(); ?>serviceprovider"><i class="fa fa-table fa-fw"></i>Service Providers</a>
                        </li>
                       <li>
                            <i <!-- class="fa fa-table fa-fw" --></i><strong>Official Users</strong>
                        </li>
                        <li>
                            <a href="<?php echo base_url(); ?>officialSP"><i class="fa fa-table fa-fw"></i>Service Providers</a>
                        </li>
                         <li class="active">
                            <a href="<?php echo base_url(); ?>customer"><i class="fa fa-table fa-fw"></i>Customers</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Service Providers</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            List of Service Providers
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="table">
                                <thead>
                                    <tr>
                                            <th>SP ID</th>
                                            <th>Username</th>
                                            <th>First name</th>
                                            <th>Last name</th>
                                            <th>Contact number</th>
                                            <th>Service</th>
                                            <!-- <th>Category</th> -->
                                            <th>E-mail Address</th>
                                            <th>Address</th>
                                            <th>Birthdate</th>
                                            <th>Confirmation</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        foreach($record AS $key => $value)
                                        {?>
                                            <tr>
                                                <td><?php echo $value->spID; ?></td>
                                                <td><?php echo $value->Username; ?></td>
                                                <td><?php echo $value->FirstName; ?></td>
                                                <td><?php echo $value->LastName; ?></td>
                                                <td><?php echo $value->ContactNumber; ?></td>
                                                <td><?php echo $value->Service; ?></td>
                                                <!-- <td><?php echo $value->Category; ?></td> -->
                                                <td><?php echo $value->Email; ?></td>
                                                <td><?php echo $value->Address; ?></td>
                                                <td><?php echo $value->Birthdate; ?></td>
                                                <td align="center">
                                                    <button type="submit" class="button accept" target-id='<?php echo $value->spID; ?>'>Accept</button> 
                                                    <button type="button" class="btn btn-danger decline" target-id='<?php echo $value->spID; ?>'>Decline</button>
                                                    
                                                </td>
                                            </tr>
                                        <?php } ?>
                                   
                                </tbody>
                            </table>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="assets/vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="assets/vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="assets/vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="assets/vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="assets/dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#table').DataTable({
            responsive: true
        });

        $('.accept').click(function(){
            var id = $(this).attr('target-id');
            $.get(window.location.origin+'/acceptSP', {id: id}, function(){
                window.location = window.location.origin+'/serviceprovider';
            });
        });

        $('.decline').click(function(){
            var id = $(this).attr('target-id');
            $.get(window.location.origin+'/declineSP', {id: id}, function(){
                window.location = window.location.origin+'/serviceprovider';
            });
        });
    });
    </script>

</body>

</html>
