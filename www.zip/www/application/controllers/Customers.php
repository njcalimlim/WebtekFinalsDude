<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customers extends CI_Controller {

	function __construct(){
		parent::__construct();
	}

	public function index()
	{
		$this->load->view('customers');
	}

	public function enableCustomer(){
		$id = $this->input->get('id');
		$this->Customer->enable($id);
	}

	public function disableCustomer(){
		$id = $this->input->get('id');
		$this->Customer->disable($id);
	}
}
