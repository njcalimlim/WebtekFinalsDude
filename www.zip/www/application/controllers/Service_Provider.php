<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Service_Provider extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	function __construct(){
		parent::__construct();
	}

	public function index()
	{
		$this->load->view('service_provider');
	}

	public function acceptSP(){
		$id = $this->input->get('id');
		$this->ServP->acceptSP($id);
	}

	public function declineSP(){
		$id = $this->input->get('id');
		$this->ServP->declineSP($id);
	}

	public function enableSP(){
		$id = $this->input->get('id');
		$this->ServP->enableSP($id);
	}

	public function disableSP(){
		$id = $this->input->get('id');
		$this->ServP->disableSP($id);
	}
}
