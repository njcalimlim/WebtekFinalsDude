<?php



class Auth_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
	
	public function doLogin($username, $password)
	{
		$customer = $this->db->get_where('customer', ['UserName' => $username, 'Password' => $password])->result();
		$sp = $this->db->get_where('service_provider', ['Username' => $username, 'Password' => $password])->result();
		$result = [];

		foreach($customer AS $key => $value)
		{
			$status = $value->user_status == '1' ? 'active' : 'inactive';
			array_push($result, ['id' => $value->cuID, 'username' => $value->UserName, 'password' => $value->Password, 'type' => 'customer', 'status' => $status]);
		}
		foreach($sp AS $key => $value)
		{
			$status = $value->Confirmation == 'accept' ? 'active' : 'inactive';
			array_push($result, ['id' => $value->spID, 'username' => $value->Username, 'password' => $value->Password, 'type' => 'sp', 'status' => $status]);
		}
		return $result;
	}
}