<?php

class Customer extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	public function getCustomers(){
		return $this->db->get('customer')->result();
	}

	public function enable($id){
		$this->db->where('cuID', $id)->update('customer', ['user_status' => '1']);
	}	

	public function disable($id){
		$this->db->where('cuID', $id)->update('customer', ['user_status' => '0']);
	}
}