<?php

class Logs extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	public function getLogs(){
		return $this->db->select("r.*, s.*, sp.*, c.*, CONCAT(c.FirstName, ' ', c.LastName) AS customer_name, CONCAT(sp.FirstName, ' ', sp.LastName) AS sp_name")->from("request r")->join("services s", "s.s_id = r.s_id")->join("service_provider sp", "sp.spID = s.spID")->join("customer c", "c.cuID = r.cuID")->get()->result();
	}

}