<?php

class ServP extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	public function getServP(){
		return $this->db->get_where('service_provider', ['Confirmation' => 'pending'])->result();
	}

	public function getAcceptedUsers(){
		return $this->db->query("SELECT * FROM service_provider WHERE Confirmation IN ('accept', 'inactive')")->result();
	}

	public function acceptSP($id){
		$this->db->where(['spID' => $id])->update("service_provider", ['Confirmation' => 'accept']);
	}

	public function declineSP($id){
		$this->db->where(['spID' => $id])->update("service_provider", ['Confirmation' => 'decline']);
	}

	public function enableSP($id){
		$this->db->where(['spID' => $id])->update("service_provider", ['Confirmation' => 'accept']);
	}

	public function disableSP($id){
		$this->db->where(['spID' => $id])->update("service_provider", ['Confirmation' => 'inactive']);
	}
}