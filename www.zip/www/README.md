1. Copy adminModule folder to htdocs for XXAMP or to www for Wamp.
2. Start Apache & MySql Server.
3. Import the database.
4. Type the following in the brower to view the register page.
	http://localhost/adminModule/register

   Type the following in the brower to view the login page.
	http://localhost/adminModule/login

   Type the following in the brower to view the Service Provider List under the Admin module.
	http://localhost/adminModule/serviceprovider

   Type the following in the brower to view the Customer List under the Admin module.
	http://localhost/adminModule/customer

   Type the following in the brower to view the Dashboard of the Admin.
	http://localhost/adminModule/Dashboard